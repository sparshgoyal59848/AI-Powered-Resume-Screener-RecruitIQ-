"""
AI-Powered Resume Screener - Flask Backend
"""

import os
import json
import re
import math
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename

# NLP & PDF
import spacy
import PyPDF2
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

app = Flask(__name__, static_folder="../frontend", static_url_path="")
CORS(app)

UPLOAD_FOLDER = "uploads"
ALLOWED_EXTENSIONS = {"pdf", "txt"}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Load spaCy model
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    from spacy.cli import download
    download("en_core_web_sm")
    nlp = spacy.load("en_core_web_sm")


# ─────────────────────────────────────────────
# SKILL TAXONOMY
# ─────────────────────────────────────────────
SKILL_KEYWORDS = {
    "programming": [
        "python", "java", "javascript", "typescript", "c++", "c#", "go", "rust",
        "ruby", "php", "swift", "kotlin", "scala", "r", "matlab", "perl",
    ],
    "web": [
        "react", "angular", "vue", "nodejs", "node.js", "express", "django",
        "flask", "fastapi", "html", "css", "sass", "graphql", "rest", "api",
        "next.js", "nuxt", "svelte",
    ],
    "data": [
        "pandas", "numpy", "scikit-learn", "tensorflow", "pytorch", "keras",
        "spark", "hadoop", "sql", "nosql", "mongodb", "postgresql", "mysql",
        "tableau", "power bi", "excel", "data analysis", "machine learning",
        "deep learning", "nlp", "computer vision",
    ],
    "cloud_devops": [
        "aws", "azure", "gcp", "docker", "kubernetes", "terraform", "jenkins",
        "ci/cd", "devops", "linux", "git", "github", "gitlab", "ansible",
        "microservices", "serverless",
    ],
    "soft_skills": [
        "leadership", "communication", "teamwork", "problem solving", "agile",
        "scrum", "project management", "collaboration", "mentoring",
    ],
}

ALL_SKILLS = [skill for skills in SKILL_KEYWORDS.values() for skill in skills]

# Education tiers
EDU_SCORES = {
    "phd": 100, "ph.d": 100, "doctorate": 100,
    "master": 85, "msc": 85, "mba": 85, "m.s": 85,
    "bachelor": 70, "bsc": 70, "b.s": 70, "b.e": 70, "b.tech": 70,
    "associate": 50, "diploma": 40, "certificate": 30,
}

SENIORITY_WEIGHTS = {
    "intern": 0, "junior": 1, "mid": 2, "senior": 3,
    "lead": 4, "principal": 5, "staff": 5, "director": 6, "vp": 7,
}


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────
def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def extract_text_from_pdf(filepath):
    text = ""
    try:
        with open(filepath, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                text += page.extract_text() or ""
    except Exception as e:
        text = ""
    return text


def extract_text_from_txt(filepath):
    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def extract_text(filepath):
    ext = filepath.rsplit(".", 1)[-1].lower()
    if ext == "pdf":
        return extract_text_from_pdf(filepath)
    return extract_text_from_txt(filepath)


def extract_skills(text):
    text_lower = text.lower()
    found = []
    for skill in ALL_SKILLS:
        # word boundary match
        pattern = r"\b" + re.escape(skill) + r"\b"
        if re.search(pattern, text_lower):
            found.append(skill)
    return list(set(found))


def extract_email(text):
    match = re.search(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}", text)
    return match.group(0) if match else "N/A"


def extract_phone(text):
    match = re.search(r"(\+?\d[\d\s\-().]{7,}\d)", text)
    return match.group(0).strip() if match else "N/A"


def extract_name(text):
    doc = nlp(text[:500])  # Check first 500 chars
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            return ent.text.strip()
    # Fallback: first non-empty line
    for line in text.split("\n"):
        line = line.strip()
        if line and len(line.split()) <= 4 and len(line) > 3:
            return line
    return "Unknown"


def extract_education_score(text):
    text_lower = text.lower()
    best = 0
    for keyword, score in EDU_SCORES.items():
        if keyword in text_lower:
            best = max(best, score)
    return best


def extract_experience_years(text):
    # Pattern: "X years of experience" or "X+ years"
    patterns = [
        r"(\d+)\+?\s*years?\s+of\s+experience",
        r"(\d+)\+?\s*years?\s+experience",
        r"experience\s+of\s+(\d+)\+?\s*years?",
    ]
    for p in patterns:
        match = re.search(p, text.lower())
        if match:
            return int(match.group(1))
    return 0


def compute_tfidf_score(resume_text, jd_text):
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    try:
        tfidf = vectorizer.fit_transform([jd_text, resume_text])
        sim = cosine_similarity(tfidf[0:1], tfidf[1:2])[0][0]
        return round(float(sim) * 100, 2)
    except Exception:
        return 0.0


def skill_match_score(resume_skills, jd_skills):
    if not jd_skills:
        return 0, [], []
    matched = [s for s in jd_skills if s in resume_skills]
    missing = [s for s in jd_skills if s not in resume_skills]
    score = (len(matched) / len(jd_skills)) * 100
    return round(score, 2), matched, missing


def compute_final_score(tfidf_score, skill_score, edu_score, exp_years, jd_exp_req):
    # Weighted composite
    w_tfidf = 0.35
    w_skill = 0.40
    w_edu = 0.15
    w_exp = 0.10

    edu_norm = min(edu_score, 100)

    exp_norm = 0
    if jd_exp_req > 0:
        exp_norm = min((exp_years / jd_exp_req) * 100, 100)
    else:
        exp_norm = min(exp_years * 10, 100)

    score = (
        w_tfidf * tfidf_score
        + w_skill * skill_score
        + w_edu * edu_norm
        + w_exp * exp_norm
    )
    return round(score, 2)


def parse_resume(filepath, jd_text, jd_skills, jd_exp_req):
    text = extract_text(filepath)
    if not text.strip():
        return None

    resume_skills = extract_skills(text)
    tfidf_score = compute_tfidf_score(text, jd_text)
    skill_score, matched_skills, missing_skills = skill_match_score(resume_skills, jd_skills)
    edu_score = extract_education_score(text)
    exp_years = extract_experience_years(text)
    final_score = compute_final_score(tfidf_score, skill_score, edu_score, exp_years, jd_exp_req)

    # Strengths / Weaknesses
    strengths = []
    weaknesses = []
    if skill_score >= 70:
        strengths.append("Strong skill alignment")
    elif skill_score < 40:
        weaknesses.append("Low skill match")

    if edu_score >= 85:
        strengths.append("Advanced education")
    elif edu_score == 0:
        weaknesses.append("Education not detected")

    if exp_years >= jd_exp_req and jd_exp_req > 0:
        strengths.append(f"{exp_years}+ yrs experience meets requirement")
    elif jd_exp_req > 0 and exp_years < jd_exp_req:
        weaknesses.append(f"Experience gap ({exp_years} vs {jd_exp_req} req)")

    if tfidf_score >= 60:
        strengths.append("High content relevance")

    return {
        "filename": os.path.basename(filepath),
        "name": extract_name(text),
        "email": extract_email(text),
        "phone": extract_phone(text),
        "skills_found": resume_skills,
        "matched_skills": matched_skills,
        "missing_skills": missing_skills,
        "experience_years": exp_years,
        "education_score": edu_score,
        "tfidf_score": tfidf_score,
        "skill_match_score": skill_score,
        "final_score": final_score,
        "strengths": strengths,
        "weaknesses": weaknesses,
        "text_preview": text[:300].replace("\n", " ").strip(),
    }


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────
@app.route("/")
def index():
    return send_from_directory("../frontend", "index.html")


@app.route("/api/screen", methods=["POST"])
def screen_resumes():
    if "resumes" not in request.files:
        return jsonify({"error": "No resume files provided"}), 400
    if "jd" not in request.form:
        return jsonify({"error": "No job description provided"}), 400

    jd_text = request.form["jd"]
    jd_skills = extract_skills(jd_text)
    jd_exp_req = extract_experience_years(jd_text)

    files = request.files.getlist("resumes")
    results = []
    errors = []

    for file in files:
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(filepath)
            try:
                result = parse_resume(filepath, jd_text, jd_skills, jd_exp_req)
                if result:
                    results.append(result)
                else:
                    errors.append(f"{filename}: Could not extract text")
            except Exception as e:
                errors.append(f"{filename}: {str(e)}")
        else:
            errors.append(f"{file.filename}: Unsupported format")

    # Rank
    results.sort(key=lambda x: x["final_score"], reverse=True)
    for i, r in enumerate(results):
        r["rank"] = i + 1
        r["recommendation"] = (
            "Strong Hire" if r["final_score"] >= 75
            else "Consider" if r["final_score"] >= 50
            else "Not Recommended"
        )

    return jsonify({
        "total": len(results),
        "jd_skills": jd_skills,
        "jd_exp_required": jd_exp_req,
        "candidates": results,
        "errors": errors,
    })


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "spacy_model": "en_core_web_sm"})


if __name__ == "__main__":
    print("🚀 Resume Screener API running at http://localhost:5000")
    app.run(debug=True, port=5000)
